// // Base URL of the backend
// const baseURL = "http://127.0.0.1:5001";

// // Run Backend Tasks
// const segmentationButton = document.getElementById('run-segmentation');
// const forecastingButton = document.getElementById('run-forecasting');
// const recommendationsButton = document.getElementById('run-recommendations');
// const outputDiv = document.getElementById('task-output');

// // Function to call backend endpoints
// async function callAPI(endpoint) {
//     try {
//         const response = await fetch(`${baseURL}${endpoint}`);
//         if (!response.ok) {
//             throw new Error(`HTTP error! Status: ${response.status}`);
//         }
//         const result = await response.json();
//         outputDiv.innerHTML = `<p>${result.message}</p>`;
//     } catch (error) {
//         outputDiv.innerHTML = `<p style="color: red;">Error: ${error.message}</p>`;
//     }
// }

// // Add event listeners to the buttons
// segmentationButton.addEventListener("click", () => callAPI("/segment-customers"));
// forecastingButton.addEventListener("click", () => callAPI("/forecast-sales"));
// recommendationsButton.addEventListener("click", () => callAPI("/recommend-products"));

// // Base URL of the backend
// const baseURL = "http://127.0.0.1:5001";

// // Run Backend Tasks
// const segmentationButton = document.getElementById('run-segmentation');
// const forecastingButton = document.getElementById('run-forecasting');
// const recommendationsButton = document.getElementById('run-recommendations');
// const outputDiv = document.getElementById('task-output');

// // Function to call backend endpoints
// async function callAPI(endpoint) {
//     try {
//         const response = await fetch(`${baseURL}${endpoint}`);
//         if (!response.ok) {
//             throw new Error(`HTTP error! Status: ${response.status}`);
//         }
//         const result = await response.json();
//         outputDiv.innerHTML = `<p>${result.message}</p>`;
//     } catch (error) {
//         outputDiv.innerHTML = `<p style="color: red;">Error: ${error.message}</p>`;
//     }
// }

// // Add event listeners to the buttons
// segmentationButton.addEventListener("click", () => callAPI("/segment-customers"));
// forecastingButton.addEventListener("click", () => callAPI("/forecast-sales"));
// recommendationsButton.addEventListener("click", () => callAPI("/recommend-products"));
// Base URL of the backend
const baseURL = "http://127.0.0.1:5001";

// Run Backend Tasks
const segmentationButton = document.getElementById('run-segmentation');
const forecastingButton = document.getElementById('run-forecasting');
const recommendationsButton = document.getElementById('run-recommendations');
const analyticsButton = document.getElementById('view-analytics');
const segmentationVizButton = document.getElementById('view-segmentation-viz');
const outputDiv = document.getElementById('task-output');

// Function to call backend endpoints
async function callAPI(endpoint, type = "message") {
    try {
        const response = await fetch(`${baseURL}${endpoint}`);
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const result = await response.json();

        if (type === "image") {
            outputDiv.innerHTML = `<img src="data:image/png;base64,${result.image}" alt="Visualization Chart">`;
        } else if (type === "chart") {
            outputDiv.innerHTML = result.chart;
        } else {
            outputDiv.innerHTML = `<p>${result.message}</p>`;
        }
    } catch (error) {
        outputDiv.innerHTML = `<p style="color: red;">Error: ${error.message}</p>`;
    }
}

// Add event listeners to the buttons
segmentationButton.addEventListener("click", () => callAPI("/segment-customers"));
forecastingButton.addEventListener("click", () => callAPI("/forecast-sales"));
recommendationsButton.addEventListener("click", () => callAPI("/recommend-products"));
analyticsButton.addEventListener("click", () => callAPI("/sales-analytics", "image"));
segmentationVizButton.addEventListener("click", () => callAPI("/customer-segmentation-visualization", "chart"));

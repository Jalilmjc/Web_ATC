import unittest
import requests

BASE_URL = "http://127.0.0.1:5001"

class TestServer(unittest.TestCase):
    def test_home(self):
        response = requests.get(f"{BASE_URL}/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("Welcome! Backend is working.", response.text)

    def test_customer_segmentation(self):
        response = requests.get(f"{BASE_URL}/segment-customers")
        self.assertEqual(response.status_code, 200)

    def test_forecasting(self):
        response = requests.get(f"{BASE_URL}/forecast-sales")
        self.assertEqual(response.status_code, 200)

if __name__ == "__main__":
    unittest.main()

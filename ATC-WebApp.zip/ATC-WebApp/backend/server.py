# from flask import Flask, request, jsonify
# import pymysql
# import sys
# from pathlib import Path

# # Resolve the absolute path to backend_logic
# backend_logic_path = Path(__file__).resolve().parent.parent / "backend_logic"
# sys.path.append("C:/Users/Admin/Desktop/ATC-WebApp/backend_logic")


# # Debug: Print the resolved path and Python path
# print(f"Backend logic path added: {backend_logic_path}")
# print("Current Python path:", sys.path)

# from backend_logic.customer_segmentation import segment_customers
# from backend_logic.sales_forecasting import forecast_sales
# from backend_logic.recommendation_system import recommend_products


# app = Flask(__name__)

# # Database Connection
# def db_connection():
#     try:
#         conn = pymysql.connect(
#             host="localhost",
#             user="root",
#             password="",  # Update with your MySQL root password if any
#             database="atc",
#             charset="utf8mb4"
#         )
#         return conn
#     except Exception as e:
#         print(f"Error connecting to database: {e}")
#         return None

# @app.route('/')
# def home():
#     return "Welcome! Backend is working."

# # Add Customer Endpoint
# @app.route('/customers', methods=['POST'])
# def add_customer():
#     data = request.json
#     conn = db_connection()
#     if conn:
#         try:
#             cursor = conn.cursor()
#             cursor.execute("""
#                 INSERT INTO Customer (FirstName, LastName, Email) 
#                 VALUES (%s, %s, %s)
#             """, (data['firstName'], data['lastName'], data['email']))
#             conn.commit()
#             return jsonify({"message": "Customer added successfully"}), 201
#         except Exception as e:
#             return jsonify({"error": str(e)}), 400
#         finally:
#             conn.close()
#     else:
#         return jsonify({"error": "Database connection failed"}), 500

# # Endpoint for Customer Segmentation
# @app.route('/segment-customers', methods=['GET'])
# def run_segmentation():
#     try:
#         segment_customers()
#         return jsonify({"message": "Customer segmentation completed successfully."}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# # Endpoint for Sales Forecasting
# @app.route('/forecast-sales', methods=['GET'])
# def run_forecasting():
#     try:
#         forecast_sales()
#         return jsonify({"message": "Sales forecasting completed successfully."}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# # Endpoint for Recommendation System
# @app.route('/recommend-products', methods=['GET'])
# def run_recommendations():
#     try:
#         recommend_products()
#         return jsonify({"message": "Product recommendations generated successfully."}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# if __name__ == '__main__':
#     app.run(debug=True, port=5001)

# from flask import Flask, request, jsonify
# import pymysql
# import sys
# import os
# from pathlib import Path

# # Resolve the absolute path to backend_logic
# backend_logic_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../backend_logic"))
# if backend_logic_path not in sys.path:
#     sys.path.append(backend_logic_path)

# # Debug: Print the resolved path and Python path
# print(f"Backend logic path added: {backend_logic_path}")
# print("Current Python path:", sys.path)

# try:
#     from customer_segmentation import segment_customers
#     from sales_forecasting import forecast_sales
#     from recommendation_system import recommend_products
#     print("Modules imported successfully.")
# except ImportError as e:
#     print(f"Error importing modules: {e}")

# app = Flask(__name__)

# # Database Connection
# def db_connection():
#     try:
#         conn = pymysql.connect(
#             host="localhost",
#             user="root",
#             password="",  # Update with your MySQL root password if any
#             database="atc",
#             charset="utf8mb4"
#         )
#         return conn
#     except Exception as e:
#         print(f"Error connecting to database: {e}")
#         return None

# @app.route('/')
# def home():
#     return "Welcome! Backend is working."

# # Add Customer Endpoint
# @app.route('/customers', methods=['POST'])
# def add_customer():
#     data = request.json
#     conn = db_connection()
#     if conn:
#         try:
#             cursor = conn.cursor()
#             cursor.execute("""
#                 INSERT INTO Customer (FirstName, LastName, Email) 
#                 VALUES (%s, %s, %s)
#             """, (data['firstName'], data['lastName'], data['email']))
#             conn.commit()
#             return jsonify({"message": "Customer added successfully"}), 201
#         except Exception as e:
#             return jsonify({"error": str(e)}), 400
#         finally:
#             conn.close()
#     else:
#         return jsonify({"error": "Database connection failed"}), 500

# # Endpoint for Customer Segmentation
# @app.route('/segment-customers', methods=['GET'])
# def run_segmentation():
#     try:
#         segment_customers()
#         return jsonify({"message": "Customer segmentation completed successfully."}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# # Endpoint for Sales Forecasting
# @app.route('/forecast-sales', methods=['GET'])
# def run_forecasting():
#     try:
#         forecast_sales()
#         return jsonify({"message": "Sales forecasting completed successfully."}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# # Endpoint for Recommendation System
# @app.route('/recommend-products', methods=['GET'])
# def run_recommendations():
#     try:
#         recommend_products()
#         return jsonify({"message": "Product recommendations generated successfully."}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# if __name__ == '__main__':
#     app.run(debug=True, port=5001)
# from flask import Flask, request, jsonify
# import pymysql
# import sys
# import os
# from pathlib import Path
# from flask_cors import CORS

# # Resolve the absolute path to backend_logic
# backend_logic_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../backend_logic"))
# if backend_logic_path not in sys.path:
#     sys.path.append(backend_logic_path)

# # Debug: Print the resolved path and Python path
# print(f"Backend logic path added: {backend_logic_path}")
# print("Current Python path:", sys.path)

# try:
#     from customer_segmentation import segment_customers
#     from sales_forecasting import forecast_sales
#     from recommendation_system import recommend_products
#     print("Modules imported successfully.")
# except ImportError as e:
#     print(f"Error importing modules: {e}")

# app = Flask(__name__)
# CORS(app)  # Enable CORS

# # Database Connection
# def db_connection():
#     try:
#         conn = pymysql.connect(
#             host="localhost",
#             user="root",
#             password="",  # Update with your MySQL root password if any
#             database="atc",
#             charset="utf8mb4"
#         )
#         return conn
#     except Exception as e:
#         print(f"Error connecting to database: {e}")
#         return None

# @app.route('/')
# def home():
#     return "Welcome! Backend is working."

# # Add Customer Endpoint
# @app.route('/customers', methods=['POST'])
# def add_customer():
#     data = request.json
#     conn = db_connection()
#     if conn:
#         try:
#             cursor = conn.cursor()
#             cursor.execute("""
#                 INSERT INTO Customer (FirstName, LastName, Email) 
#                 VALUES (%s, %s, %s)
#             """, (data['firstName'], data['lastName'], data['email']))
#             conn.commit()
#             return jsonify({"message": "Customer added successfully"}), 201
#         except Exception as e:
#             return jsonify({"error": str(e)}), 400
#         finally:
#             conn.close()
#     else:
#         return jsonify({"error": "Database connection failed"}), 500

# # Endpoint for Customer Segmentation
# @app.route('/segment-customers', methods=['GET'])
# def run_segmentation():
#     try:
#         print("Debug: Segmentation logic started.")
#         return jsonify({"message": "Customer segmentation completed successfully."}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# # Endpoint for Sales Forecasting
# @app.route('/forecast-sales', methods=['GET'])
# def run_forecasting():
#     try:
#         forecast_sales()
#         return jsonify({"message": "Sales forecasting completed successfully."}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# # Endpoint for Recommendation System
# @app.route('/recommend-products', methods=['GET'])
# def run_recommendations():
#     try:
#         recommend_products()
#         return jsonify({"message": "Product recommendations generated successfully."}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# if __name__ == '__main__':
#     app.run(debug=True, port=5001)
from flask import Flask, request, jsonify
import pymysql
import sys
import os
from pathlib import Path
from flask_cors import CORS
import matplotlib.pyplot as plt
import plotly.express as px
import pandas as pd
import io
import base64

# Resolve the absolute path to backend_logic
backend_logic_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../backend_logic"))
if backend_logic_path not in sys.path:
    sys.path.append(backend_logic_path)

# Debug: Print the resolved path and Python path
print(f"Backend logic path added: {backend_logic_path}")
print("Current Python path:", sys.path)

try:
    from customer_segmentation import segment_customers
    from sales_forecasting import forecast_sales
    from recommendation_system import recommend_products
    print("Modules imported successfully.")
except ImportError as e:
    print(f"Error importing modules: {e}")

app = Flask(__name__)
CORS(app)  # Enable CORS

# Database Connection
def db_connection():
    try:
        conn = pymysql.connect(
            host="localhost",
            user="root",
            password="",  # Update with your MySQL root password if any
            database="atc",
            charset="utf8mb4"
        )
        return conn
    except Exception as e:
        print(f"Error connecting to database: {e}")
        return None

@app.route('/')
def home():
    return "Welcome! Backend is working."

# Add Customer Endpoint
@app.route('/customers', methods=['POST'])
def add_customer():
    print("POST /customers called")
    data = request.json
    conn = db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO Customer (FirstName, LastName, Email) 
                VALUES (%s, %s, %s)
            """, (data['firstName'], data['lastName'], data['email']))
            conn.commit()
            return jsonify({"message": "Customer added successfully"}), 201
        except Exception as e:
            return jsonify({"error": str(e)}), 400
        finally:
            conn.close()
    else:
        return jsonify({"error": "Database connection failed"}), 500

# Endpoint for Customer Segmentation
@app.route('/segment-customers', methods=['GET'])
def run_segmentation():
    try:
        print("Debug: Segmentation logic started.")
        return jsonify({"message": "Customer segmentation completed successfully."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Endpoint for Sales Forecasting
@app.route('/forecast-sales', methods=['GET'])
def run_forecasting():
    try:
        forecast_sales()
        return jsonify({"message": "Sales forecasting completed successfully."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Endpoint for Recommendation System
@app.route('/recommend-products', methods=['GET'])
def run_recommendations():
    try:
        recommend_products()
        return jsonify({"message": "Product recommendations generated successfully."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Endpoint for Sales Analytics
@app.route('/sales-analytics', methods=['GET'])
def sales_analytics():
    conn = db_connection()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500

    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT ProductID, SUM(TotalPrice) AS TotalSales, COUNT(*) AS TotalOrders
            FROM OrderDetails
            GROUP BY ProductID
        """)
        data = cursor.fetchall()
        df = pd.DataFrame(data, columns=["ProductID", "TotalSales", "TotalOrders"])

        plt.figure(figsize=(10, 6))
        plt.bar(df["ProductID"], df["TotalSales"], color="blue")
        plt.xlabel("Product ID")
        plt.ylabel("Total Sales")
        plt.title("Product Performance - Total Sales")
        plt.tight_layout()

        buf = io.BytesIO()
        plt.savefig(buf, format="png")
        buf.seek(0)
        image_base64 = base64.b64encode(buf.read()).decode("utf-8")
        buf.close()

        return jsonify({"image": image_base64}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        conn.close()

# Endpoint for Customer Segmentation Visualization
@app.route('/customer-segmentation-visualization', methods=['GET'])
def customer_segmentation_visualization():
    conn = db_connection()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500

    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT Segment, COUNT(*) AS CustomerCount
            FROM Customer
            GROUP BY Segment
        """)
        data = cursor.fetchall()
        df = pd.DataFrame(data, columns=["Segment", "CustomerCount"])

        fig = px.pie(df, values="CustomerCount", names="Segment", title="Customer Segmentation")
        pie_chart_html = fig.to_html()

        return jsonify({"chart": pie_chart_html}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        conn.close()

if __name__ == '__main__':
    app.run(debug=True, port=5001)
import pymysql
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

def fetch_customer_data():
    conn = pymysql.connect(host="localhost", user="root", password="", database="atc")
    query = "SELECT CustomerID, TotalSpend, LastPurchaseDate FROM Customer;"
    data = pd.read_sql(query, conn)
    conn.close()
    return data

def segment_customers():
    data = fetch_customer_data()
    data['LastPurchaseDays'] = (pd.Timestamp.today() - pd.to_datetime(data['LastPurchaseDate'])).dt.days
    features = data[['TotalSpend', 'LastPurchaseDays']].fillna(0)

    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(features)

    kmeans = KMeans(n_clusters=3, random_state=0)
    data['Segment'] = kmeans.fit_predict(scaled_features)

    conn = pymysql.connect(host="localhost", user="root", password="", database="atc")
    cursor = conn.cursor()
    for _, row in data.iterrows():
        cursor.execute("UPDATE Customer SET Segment = %s WHERE CustomerID = %s", (row['Segment'], row['CustomerID']))
    conn.commit()
    conn.close()

if __name__ == "__main__":
    segment_customers()

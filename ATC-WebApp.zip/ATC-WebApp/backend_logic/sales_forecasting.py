import pymysql
import pandas as pd
from prophet import Prophet

def fetch_sales_data():
    conn = pymysql.connect(host="localhost", user="root", password="", database="atc")
    query = "SELECT OrderDate, SUM(TotalOrderPrice) as Revenue FROM `Order` GROUP BY OrderDate;"
    sales_data = pd.read_sql(query, conn)
    conn.close()
    return sales_data

def forecast_sales():
    sales_data = fetch_sales_data()
    sales_data.rename(columns={'OrderDate': 'ds', 'Revenue': 'y'}, inplace=True)

    model = Prophet()
    model.fit(sales_data)
    future = model.make_future_dataframe(periods=30)
    forecast = model.predict(future)

    conn = pymysql.connect(host="localhost", user="root", password="", database="atc")
    cursor = conn.cursor()
    for _, row in forecast.iterrows():
        cursor.execute("INSERT INTO SalesAnalysis (MonthlySales, TotalRevenue) VALUES (%s, %s)", (row['ds'], row['yhat']))
    conn.commit()
    conn.close()
    print("Sales forecasting logic executed.") #newly added
if __name__ == "__main__":
    forecast_sales()

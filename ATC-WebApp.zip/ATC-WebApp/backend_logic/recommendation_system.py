import pymysql
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

def fetch_purchase_data():
    conn = pymysql.connect(host="localhost", user="root", password="", database="atc")
    query = "SELECT CustomerID, ProductID FROM OrderDetails;"
    purchase_data = pd.read_sql(query, conn)
    conn.close()
    return purchase_data

def recommend_products():
    purchase_data = fetch_purchase_data()
    customer_product_matrix = purchase_data.pivot_table(index='CustomerID', columns='ProductID', aggfunc='size', fill_value=0)
    similarity = cosine_similarity(customer_product_matrix)

    conn = pymysql.connect(host="localhost", user="root", password="", database="atc")
    cursor = conn.cursor()
    for customer_id in range(len(customer_product_matrix)):
        similar_customers = similarity[customer_id].argsort()[::-1][:5]
        recommendations = customer_product_matrix.iloc[similar_customers].sum(axis=0).sort_values(ascending=False).index.tolist()[:5]
        cursor.execute("UPDATE Customer SET Recommendations = %s WHERE CustomerID = %s", (','.join(map(str, recommendations)), customer_id + 1))
    conn.commit()
    conn.close()
    print("Recommendation logic executed.")

if __name__ == "__main__":
    recommend_products()
